﻿Imports ZXing

Public Class Form1

    Private Sub ButtonCREAR_Click(sender As System.Object, e As System.EventArgs) Handles ButtonCREAR.Click

        Dim GENERADOR As BarcodeWriter = New BarcodeWriter


        If RadioButtonPDF417.Checked Then
            GENERADOR.Format = BarcodeFormat.PDF_417
        ElseIf RadioButton128.Checked Then
            GENERADOR.Format = BarcodeFormat.CODE_128
        ElseIf RadioButtonQR.Checked Then
            GENERADOR.Format = BarcodeFormat.QR_CODE


        End If

        Try
            Dim IMAGEN As Bitmap = New Bitmap(GENERADOR.Write(TextBoxGENERAR.Text), PictureBoxGENERAR.Width, PictureBoxGENERAR.Height)
            PictureBoxGENERAR.Image = IMAGEN
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        e.Graphics.DrawImage(PictureBoxGENERAR.Image, 0, 0)

    End Sub

    Private Sub ButtonIMPRIMIR_Click(sender As System.Object, e As System.EventArgs) Handles ButtonIMPRIMIR.Click

        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()

    End Sub

    Private Sub ButtonGUARDAR_Click(sender As System.Object, e As System.EventArgs) Handles ButtonGUARDAR.Click

        SaveFileDialog1.DefaultExt = ".jpg"
        SaveFileDialog1.FileName = TextBoxGENERAR.Text

        If SaveFileDialog1.ShowDialog Then
            Try
                PictureBoxGENERAR.Image.Save(SaveFileDialog1.FileName, Imaging.ImageFormat.Jpeg)
                MsgBox("ممتاز")
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub ButtonLEER_Click(sender As System.Object, e As System.EventArgs) Handles ButtonLEER.Click

        If OpenFileDialog1.ShowDialog Then
            Try
                TextBoxLEER.Clear()
                PictureBoxLEER.ImageLocation = OpenFileDialog1.FileName
                ESPERA(1000)
                Dim DECODER As BarcodeReader = New BarcodeReader
                TextBoxLEER.Text = DECODER.Decode(PictureBoxLEER.Image).ToString
            Catch ex As Exception
            End Try
        End If

    End Sub


    Public Sub ESPERA(ByVal INTERVALO As Integer)

        Dim PARADA As New Stopwatch
        PARADA.Start()
        Do While PARADA.ElapsedMilliseconds < INTERVALO
            Application.DoEvents()
        Loop
        PARADA.Stop()

    End Sub

    Private Sub PictureBoxLEER_Click(sender As Object, e As EventArgs) Handles PictureBoxLEER.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub
End Class
